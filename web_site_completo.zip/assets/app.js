
// Ano
document.addEventListener('DOMContentLoaded',()=>{
  const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
});
// Countdown 2 meses
(function(){
  const el = document.getElementById('timer'); if(!el) return;
  const end = new Date(); end.setMonth(end.getMonth()+2);
  function tick(){
    const diff = end - new Date();
    if(diff <= 0){ el.textContent = 'Expirado'; return; }
    const d = Math.floor(diff/(1000*60*60*24));
    const h = Math.floor((diff/(1000*60*60))%24);
    const m = Math.floor((diff/(1000*60))%60);
    const s = Math.floor((diff/1000)%60);
    el.textContent = `${d}d ${h}h ${m}m ${s}s`;
  }
  tick(); setInterval(tick,1000);
})();
// Scroll reveal
const observer = new IntersectionObserver((entries)=>{
  entries.forEach(e=>{ if(e.isIntersecting){ e.target.classList.add('show'); observer.unobserve(e.target);} });
},{threshold:0.12});
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));

// PWA: register service worker
if('serviceWorker' in navigator){
  window.addEventListener('load', ()=>{
    navigator.serviceWorker.register('/service-worker.js').catch(()=>{});
  });
}
