# Site completo – Tornar-se um Trader de Sucesso

Este pacote contém um **site completo**, pronto para publicar no **GitHub Pages** (recomendado) ou **Netlify**.

## Publicar no GitHub Pages
1. Crie o repositório (ou use o seu): `grgr23998-ship-it/CAMINHO-PARA-TRADER-DE-SUCESSO-`
2. Envie **todos os arquivos e pastas** desta pasta (incluindo `.nojekyll`, `assets/`, `blog/`, etc.).
3. Vá em **Settings → Pages** e selecione **Deploy from a branch** → **Branch: main** e **/ (root)**. Salve.
4. URL final:
   `https://grgr23998-ship-it.github.io/CAMINHO-PARA-TRADER-DE-SUCESSO-/`

## Publicar no Netlify
1. Crie conta em https://netlify.com
2. **Add new site → Deploy manually** e arraste **esta pasta**.
3. Link gerado: `https://SEU-NOME.netlify.app` (você pode renomear).

## Ajustes rápidos
- **Checkout (Kirvano):** o botão já usa seu link.
- **Contador:** 2 meses (arquivo `assets/app.js` → `end.setMonth(end.getMonth()+2)`).
- **Marca d’água NAS100:** presente no herói (`.watermark::after`).
- **Capa:** `assets/img/capa.png`.
- **PWA:** `manifest.webmanifest` + `service-worker.js` (navegação offline básica).
- **Formulário de contato:** já compatível com **Netlify Forms**. Para usar **Formspree**, troque o `<form>` por um action do Formspree.

## Pós-compra (Obrigado)
- Configure o redirecionamento no seu checkout (Kirvano) para: `/obrigado.html` (opcional).

Bom lançamento! 🚀
