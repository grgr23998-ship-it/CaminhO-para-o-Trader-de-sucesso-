# CAMINHO PARA TRADER DE SUCESSO – Site

Pronto para publicar no repositório: **grgr23998-ship-it/CAMINHO-PARA-TRADER-DE-SUCESSO-**

## Como publicar (2 minutos)
1. Baixe este pacote (ZIP) e extraia.
2. Abra o repositório no GitHub: https://github.com/grgr23998-ship-it/CAMINHO-PARA-TRADER-DE-SUCESSO-
3. Clique em **Add file → Upload files** e envie **todos os arquivos e pastas**, inclusive:
   - `index.html`, `capa.png`, `favicon.ico`, `privacy.html`, `terms.html`, `refund.html`, `robots.txt`, `sitemap.xml`, `.nojekyll`
   - a pasta `.github/workflows/pages.yml` (mantenha a estrutura de pastas)
4. Clique em **Commit changes**.
5. Vá em **Settings → Pages** e deixe **Build and deployment → Source = GitHub Actions** (padrão deste workflow).
6. Volte para a aba **Actions** e aguarde o workflow **Deploy to GitHub Pages** concluir (✔️).
7. Seu site ficará disponível em:
   https://grgr23998-ship-it.github.io/CAMINHO-PARA-TRADER-DE-SUCESSO-/

> OBS: o repositório deve ter a branch `main`. Se a sua branch principal for `master`, renomeie para `main` ou ajuste o workflow.

## Personalizações
- Edite textos e preços em `index.html`.
- O botão de compra já aponta para o seu link Kirvano.
- A contagem regressiva é de 2 meses (edite no final do `index.html` se quiser).
- Troque `capa.png` para atualizar a capa.
