# Página de Vendas – Tornar-se um Trader de Sucesso

Este pacote contém tudo pronto para publicar sua página em **GitHub Pages** ou **Netlify**.

## Arquivos
- `index.html` — Página de vendas completa (responsiva, com animações, contagem de 2 meses e CTA para o checkout).
- `capa.png` — Capa do eBook usada na página e nas metas OG (prévia de link).
- `favicon.ico` — Ícone do site.
- `bonus_apresentacao_ebook.pdf` — PDF de apresentação (bônus para divulgação).
- `privacy.html`, `terms.html`, `refund.html` — Páginas institucionais.
- `robots.txt`, `sitemap.xml` — Arquivos SEO básicos.

---

## Publicar no GitHub Pages (grátis e confiável)
1. Crie uma conta em https://github.com (se não tiver).
2. Clique em **New Repository** e crie um repositório **público** (ex.: `pagina-vendas`).
3. Abra o repositório e clique em **Add file > Upload files**.
4. Faça upload de **todos os arquivos** desta pasta (index.html, capa.png, etc.).
5. Vá em **Settings > Pages**.
6. Em **Source**, escolha a branch **main** e a pasta **/(root)**. Salve.
7. Aguarde ~1 minuto. Seu site ficará em:  
   `https://SEU-USUARIO.github.io/pagina-vendas/`

> **Dica:** Renomeie `SEU-USUARIO` pelo seu usuário do GitHub e `pagina-vendas` pelo nome do repositório.

---

## Publicar no Netlify (muito simples)
1. Acesse https://www.netlify.com e crie login.
2. Clique em **Add new site > Deploy manually**.
3. **Arraste a pasta inteira** ou faça upload **dos arquivos** (index.html, capa.png etc.).
4. O Netlify gera um link: `https://NOME.netlify.app`. Você pode renomear em **Site settings**.

---

## Domínio próprio (opcional)
- **GitHub Pages:** crie um arquivo `CNAME` (texto puro) com o seu domínio, ex.: `meusite.com`. Aponte o DNS (CNAME) do seu domínio para `SEU-USUARIO.github.io`.
- **Netlify:** em **Domain settings**, adicione o domínio. Netlify fornecerá os registros DNS (CNAME/A) e SSL automático.

---

## Como editar o site
- **Texto e preços:** edite no `index.html`. Procure por “Oferta de Lançamento”, “R$ 97” etc.
- **Link do botão (checkout):** procure `pay.kirvano.com/...` e substitua, se necessário.
- **Contagem de 2 meses:** no `<script>` do `index.html` há:
  ```js
  const end = new Date(); end.setMonth(end.getMonth()+2);
  ```
  Para mudar, altere o `+2`.
- **Capa e OG:** a imagem exibida é `capa.png`. As prévias nas redes usam `<meta property="og:image" content="capa.png">` — mantenha esse arquivo no mesmo nível do `index.html`.
- **Favicon:** substitua `favicon.ico` por outro, se quiser.
- **Bônus (PDF):** arquivo `bonus_apresentacao_ebook.pdf` — você pode trocar por outro PDF e manter o mesmo nome.

---

## Coleta de leads (opcional)
Para captar e-mails sem backend:
- **Formspree**: crie um formulário gratuito em https://formspree.io e cole o `action` no seu `<form>`.
- **Netlify Forms**: no Netlify, adicione `name="contato"` e o atributo `netlify` no `<form>`. Exemplo:
  ```html
  <form name="contato" method="POST" netlify>
    <input type="email" name="email" placeholder="Seu melhor e-mail" required>
    <button type="submit">Quero receber novidades</button>
  </form>
  ```

---

## Métricas e anúncios (opcional)
- **Google Tag Manager (GTM):** crie um contêiner em https://tagmanager.google.com e insira os trechos padrão (head/body) no `index.html`.
- **Meta Pixel:** crie seu pixel e insira o script no `<head>`. Use parâmetros UTM no botão de compra:  
  `https://pay.kirvano.com/SEU-LINK?utm_source=site&utm_medium=cta&utm_campaign=lancamento`

---

## Boas práticas
- **SEO:** mantenha título e descrição relevantes (já configurados). Use `sitemap.xml` e `robots.txt`.
- **Performance:** evite imagens enormes; `capa.png` já está otimizada. Prefira `.png`/`.webp`.
- **Acessibilidade:** use textos alternativos nas imagens (já incluídos).
- **Legal:** mantenha o aviso de risco no rodapé. Atualize e-mails de contato nas páginas de política.

---

## Suporte
Dúvidas comuns:
- O site não abre no GitHub Pages? Verifique **Settings > Pages** e se os **arquivos estão na raiz**.
- A capa não aparece? Confirme se `capa.png` está no **mesmo nível** do `index.html`.
- Link do botão não funciona? Garanta que o URL do checkout está correto e acessível.

Bom lançamento! 🚀
